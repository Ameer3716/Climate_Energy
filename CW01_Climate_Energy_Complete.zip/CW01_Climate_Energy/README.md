# CW01 climate and energy exploratory data analysis

**Word report added:** `CW01_Climate_Energy_Report.docx` is the accompanying 27-page report with an editable cover, report guide, the full narrative, 16 native Word tables, print-sized analytical figures and two labelled notebook-output captures. Fill in the student name and ID on the cover. The captures are also available under `report_screenshots`. Figures are reformatted from the same analytical data for print readability; the original eleven exported figures remain under `outputs/figures`.

Start with **CW01_Climate_Energy_EDA.ipynb**. It contains the report, executable code, completed outputs, eleven figures, evidence-based reference commentary, and the GenAI interpretation and critique task. **CW01_Climate_Energy_EDA.html** is the offline reading copy and opens in a browser without installing Python. **CROSS_VERIFICATION.md** records the findings from checking the supplied review and the fixes made.

## Before submission

The brief allows AI support for coding, debugging and understanding, and requires an AI interpretation of selected correlations. It explicitly requires the submitted written analysis, interpretations and conclusions to be the student's own words. This package therefore identifies its prose as AI-generated worked-reference commentary. Review and understand the results, write your own commentary and critique, and disclose the assistance accurately. Do not submit the reference prose under a declaration that you wrote it. No student name, ID, originality declaration or unverified claim of authorship has been inserted.

The required submission is the **.ipynb notebook on GCULearn**, rather than this whole ZIP. The brief lists **26 October at 3pm**; confirm the year and local deadline in GCULearn. This package does not submit anything or upload to a university account.

## Run in Google Colab

1. Extract this ZIP and open https://colab.research.google.com/.
2. Select **File → Upload notebook** and choose `CW01_Climate_Energy_EDA.ipynb`.
3. Select **Runtime → Run all**. Upload `data/global_climate_energy_assessment_2026.csv` when asked. Alternatively, upload the CSV through Colab's file panel before running.
4. Wait for all cells to finish. The notebook checks the source bytes and parsed-data hash and validates the cleaned data. The final output states that validation passed.
5. Review the figures and tables and write the final narrative in your own words. Download the resulting notebook with its outputs using **File → Download → Download .ipynb**.

Colab's temporary storage is cleared between sessions. The notebook can regenerate its exports from the original CSV, so re-upload that file when needed. A differently named upload is accepted if it contains the same parsed data. Formatting-only byte changes, such as different line endings, produce a warning and continue if all parsed rows, columns and values are identical. A change to the dataset values is still rejected, so another public version cannot be substituted silently.

## Run locally

Use Python 3.10 or later. From a terminal in this extracted folder:

```bash
python -m pip install -r requirements.txt
python reproduce_analysis.py
```

The script reads the CSV under `data`, writes the cleaned CSV and all tables and figures, and performs the same numerical checks. It does not regenerate the notebook or HTML. When IPython is unavailable, tables are printed as text and figures are still saved to PNG files.

## Files

| Path | Purpose |
| --- | --- |
| `CW01_Climate_Energy_EDA.ipynb` | Main executed Colab-compatible report |
| `CW01_Climate_Energy_Report.docx` | Accompanying illustrated Word report with cover page and editable tables |
| `CW01_Climate_Energy_EDA.html` | Self-contained offline report with embedded outputs |
| `reproduce_analysis.py` | All analysis code in notebook order |
| `requirements.txt` | Python dependencies |
| `data/global_climate_energy_assessment_2026.csv` | Unchanged supplied assessment CSV |
| `data/global_climate_energy_cleaned.csv` | Cleaned analytical data with renewable bands |
| `outputs/figures/` | Eleven full-resolution analysis figures |
| `report_screenshots/` | Two rendered extracts of actual saved notebook code and outputs |
| `outputs/tables/` | Descriptive summaries, cross-tabs, correlations and cleaning audits |
| `outputs/validation_summary.json` | Cleaning counts, dimensions, hash and software versions |
| `outputs/package_verification.json` | Independent rerun and structural verification results |
| `REQUIREMENTS_COVERAGE.md` | Every requested assessment element mapped to notebook evidence |
| `AI_USE_AND_REVIEW.md` | Transparent AI use and student review guidance |
| `CROSS_VERIFICATION.md` | Confirmed review findings, changes and disputed recommendations |
| `source_documents/` | The supplied brief and feature guide, unchanged |
| `MANIFEST_SHA256.txt` | Integrity hashes for packaged files |

## Important data decisions

- Eight duplicate rows are removed, leaving 4,000 observations and ten countries with 400 observations each.
- The export index is excluded from analysis and preserved as a source identifier in audits.
- Country whitespace, region case and date types are standardised.
- There are 200 original missing numerical cells. Five implausible or invalid numerical cells and one unverified negative price are set aside.
- Country median imputation fills 206 cells across 205 rows. No global fallback is needed.
- The three-standard-deviation rule identifies 37 valid unusual cells across 35 rows; these remain in the primary dataset.
- The negative price is retained in a sensitivity alternative because its market convention is unknown.
- Repeated observed endpoints are audited and retained: 7 emissions values at 40, and 11 and 101 industry values at 25 and 112 respectively. Possible synthetic clipping is an uncertainty, not a proven entry error.
- The final cleaned export has 4,000 rows and 13 columns, including the derived renewable band. The base cleaned data has 12 columns.
- Emissions, consumption and price units are unspecified by the guide. No physical units, currency, causal effects or real-world policy impacts are invented.

The analysis and figure outputs were generated by running every notebook code cell sequentially in a fresh Python namespace and recording standard notebook MIME outputs. A separate script rerun checks reproducibility. A browser-based Colab session was not available for an interactive UI test.
