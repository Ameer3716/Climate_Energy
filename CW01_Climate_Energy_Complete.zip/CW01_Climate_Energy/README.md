# CW01 climate and energy analysis

## Files

- `CW01_Climate_Energy_Report.docx`: illustrated report with university cover, editable student details, analytical tables, figures, conclusions and sources.
- `CW01_Climate_Energy_EDA.ipynb`: executed notebook and complete analytical outputs; this is the submission format specified by the assessment.
- `data`: original assessment CSV and cleaned analytical dataset.
- `supporting_tables`: principal cleaning audits, numerical summaries and sensitivity checks.
- `report_screenshots`: rendered extracts of saved notebook code and outputs.
- `reproduce_analysis.py` and `requirements.txt`: local reproduction files.

## Run

In Colab, upload the notebook, choose Run all and upload the original assessment CSV when prompted.

Locally, open a terminal in this folder and run:

```bash
python -m pip install -r requirements.txt
python reproduce_analysis.py
```

The script regenerates all analytical tables and figures under `outputs`. Fill in the student name and ID on the report cover. The logo is reproduced from the supplied assessment brief. Its deadline is shown exactly as supplied; check GCULearn for the applicable local submission time.

## Chart updates and verification

Count labels are clear of gridlines. Three additional figures show separate
country panels for energy use, renewable share and industry against emissions,
using shared axis limits. The industry charts mark the possible ceiling at 112.
All 14 code cells ran without errors. The cleaned data and all 40 regenerated
tables matched the previous results and an independent run. The notebook embeds
14 figures. The simplified Word report has 31 pages and 19 editable tables;
all pages, figures and the two notebook-output captures were checked visually.
The analysis was run locally; Colab's own interface has not been tested.
