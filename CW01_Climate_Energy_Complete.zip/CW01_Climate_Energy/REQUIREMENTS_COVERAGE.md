# Assessment requirement coverage

The supplied brief requests a Google Colab report submitted as `.ipynb`. The main notebook is the assessed-format deliverable; other files support review and reproducibility. All technical tasks and worked-reference analytical sections are present. The student-authorship requirement remains a personal submission responsibility: AI-generated reference commentary and critique must be replaced with the student's own work before submission.

| Brief requirement | Notebook location | Evidence or treatment |
| --- | --- | --- |
| Describe the dataset and relevance | 1.1 | Synthetic provenance, energy and emissions context, known and unknown units |
| Discuss common real-world data problems | 1.1 | Missingness, duplicates, labels, dates and invalid values |
| Explain the report's purpose | Opening and 1.1 | Scope and reason for EDA |
| State two or three analytical questions | 1.1 | Three explicit questions answered again in 4.1 |
| Use supplied assessment dataset only | 1.2 | Byte and parsed-data SHA256 checks; formatting-only changes allowed with warning; changed values rejected |
| Appropriate data loading code | 1.2 | pandas CSV loading with Colab upload fallback |
| Dimensions, structure, types and first records | 1.2 | Raw shape, head, info and schema table |
| Identify quality issues systematically | 1.2–1.3 | Missing counts, exact duplicates, label audit, validity checks and repeated endpoint audit |
| Explain analytical effect of quality issues | 1.1 and 1.3 | Group fragmentation, distorted means and relationships, ambiguous dates |
| Investigate distribution of missing values | 1.4 | Original and post-check counts by country and year, country rate heatmap |
| Impute at least one variable with justification | 1.4 | Country median method and complete field-level audit |
| Consider imputation alternatives | 1.4 and 3.3 | Global median, row deletion, interpolation, regression and sensitivity comparisons |
| Address duplicates | 1.3 | Eight removed exact records exported with source row positions |
| Address irrelevant columns | 1.3 and 1.5 | Export index excluded; source ID retained separately in audits |
| Address inconsistent labels and types | 1.3 | Country whitespace, region case, explicit day-first datetime parsing |
| Address obvious entry errors | 1.3 | Invalid percentages and implausible temperature identified without guessing original values |
| Distinguish uncertain prices | 1.3 and 3.3 | Negative price unverified; retained-price alternative quantified |
| Apply three-SD outlier threshold | 1.3 and 1.5 | Means, sample SDs, lower/upper thresholds, before and after validity checks |
| Distinguish unusual from erroneous | 1.5 | Invalid −8% missed by raw threshold; valid tail observations retained |
| Justify retain, remove or alter decisions | 1.3–1.5 | Decision prose, suspect-cell table, imputation audit and outlier detail |
| Report cleaning impact and final suitability | 1.5 | Stage dimensions and missingness, assertions and validation summary |
| Select justified numerical/categorical variables | 2.1 | Links selection to all three questions |
| Numerical summaries and visualisations | 2.1 | Means, medians, SD, quartiles, IQR, skewness, histograms and boxplots |
| Interpret centre, spread, shape and unusual values | 2.1 | Evidence-linked discussion, two-humped renewable share, clustered urban share and potential floor/ceiling effects |
| Categorical frequencies and interpretation | 2.2 | Country, region and income counts, percentages and charts |
| Convert numerical variable into categories | 2.3 | Renewable bands below 25%, 25% to below 50%, 50% to 100% |
| Justify boundaries and number of categories | 2.3 | Quarter and majority contribution, proximity of 25% to Q1, and distinction from clustering at the histogram dip |
| Visualise and interpret new category | 2.3 | Counts and percentages, boundary assertions and bar chart |
| Discuss information loss from categorisation | 2.3 | Distances lost, boundary discontinuities and unequal widths |
| Explore categorical relationships | 3.1 | Region/income by band counts and row percentages, stacked bars |
| Use pivots or cross-tabulations | 3.1 | Region–income count cross-tab, country membership, median renewable pivot |
| Additional numerical versus categorical evidence | 3.1 | Country boxplots for emissions, consumption and renewable share |
| Interpret differences, similarities and imbalance | 3.1 | Explicit regional/income percentages, structural gaps and country composition |
| Correlation matrix and overall pattern | 3.2 | Eight-variable Pearson and Spearman matrices plus heatmap and commentary |
| Select two or three correlations | 3.2 | Three emissions relationships selected and justified |
| GenAI initial interpretation | 3.4 | Exact prompt and actual AI-generated response with date and provenance |
| Include AI output or clearly identified extract | 3.4 | Full brief initial response in quoted form |
| Check AI against coefficients and visual evidence | 3.5 | Coefficient checks, country-coloured plots and within-country comparisons |
| Identify what AI got right and missed | 3.5 | Directions, magnitudes, country composition, imputation and dependence |
| Identify unsupported causal claims | 3.5 | Checks the actual response and accurately reports that no unsupported causal claim appears |
| Provide corrected or improved interpretation | 3.5 | Complete worked-reference improved interpretation |
| Suitable relationship visualisations | 3.1–3.3 | Stacked charts, correlation heatmap, pooled and demeaned scatterplots |
| Synthesize and prioritise main findings | 4.1 | Three ranked findings and answers to each question, emphasising within-country attenuation |
| Explain answered and partially answered questions | 4.1 | Sample distributions supported; group effects not separated |
| Evaluate evidence strength and relevance | 4.2 | Agreement of methods, reproducible audit, sensitivity and scope limits |
| Discuss limitations and uncertainty | 4.2 | Synthetic data, units, missingness, dependence, thresholds and omitted factors |
| One or two focused next steps | 4.3 | Metadata verification and a focused seasonal check on the renewable–emissions association |
| Conclusions grounded in earlier analysis | 4.1–4.3 | Uses already reported findings; proposed further work is not a new result |
| Concise notebook report with code, figures and commentary | Entire notebook | Ordered sections, embedded outputs and navigable HTML companion |
| Transparent use of AI | Opening, 3.4–3.5 and 5 | Worked-reference labelling and full disclosure |
| Student-authored final narrative and critique | Personal responsibility before submission | Review and replace AI reference prose; not claimed complete on the student's behalf |
| Student originality declaration | Personal responsibility before submission | No declaration fabricated or signed |
| Submit `.ipynb` through GCULearn | README instructions | No account access or submission performed |

## Marking weights

| Assessment criterion | Weight | Notebook coverage |
| --- | --- | --- |
| Data understanding and preparation | 20% | Section 1 |
| Univariate analysis | 30% | Section 2 |
| Bivariate analysis | 30% | Section 3 |
| Conclusions, limitations and critical judgement | 20% | Section 4 |

No grade is predicted or guaranteed by the coverage map.

## Accompanying Word report

`CW01_Climate_Energy_Report.docx` provides the illustrated reading copy with a cover, report guide, 16 editable summary tables, print-sized analytical figures, conclusions, sources and two labelled saved-output captures. The notebook remains the submission format specified by the brief. Complete audits and all 40 CSV tables remain in the ZIP. Student name and ID fields on the Word cover are editable and have not been guessed.
