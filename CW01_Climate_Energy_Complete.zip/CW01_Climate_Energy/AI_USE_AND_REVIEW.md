# AI assistance and review

This package is an AI-assisted worked reference. ChatGPT helped design the cleaning pipeline, write and debug code, produce the initial correlation interpretation, draft the critique, and draft the surrounding commentary and conclusions. The empirical numbers come from execution against the supplied assessment file, rather than an alternative online dataset.

The assessment brief permits coding and learning support, but says AI must not generate analysis, interpretation or conclusions submitted as the student's own work. The package is labelled accordingly. It does not contain a signed originality declaration. A disclosure should accurately reflect the assistance actually retained in the final submission and follow the module's declaration process.

## Review the actual evidence

Use these focused questions when writing your own commentary. They are review prompts, not additional assessment deliverables.

1. Why do 4,008 raw records become 4,000, and why is the export index excluded from correlation?
2. Which entries are impossible by definition, which require contextual judgement, and why is a negative price treated separately?
3. Why use country medians rather than a global median or deleting incomplete rows? What variation is lost?
4. Which invalid value is missed by the original three-SD rule? Why are valid statistical outliers retained?
5. What do the median and IQR say about each focal distribution? Do histogram shapes agree with the numerical summaries?
6. Why do 400 observations for each country not make regions or income groups equally represented?
7. Why choose 25% and 50% renewable boundaries? What happens exactly at 25%, 50% and 100%?
8. What do the region and income row percentages show, and which apparent group effects can actually be country composition?
9. Why does renewable–emissions correlation change from about −0.674 to −0.259 after country demeaning?
10. What did the AI interpretation get right, and which omitted context materially changes the interpretation?
11. Why is a correlation neither a slope nor proof of a causal policy effect?
12. Which two next investigations would most improve confidence in the findings?

## GenAI task provenance

Notebook Section 3.4 records the exact prompt and initial ChatGPT response generated in this session on 16 October 2026. Section 3.5 provides a worked example of checking it using coefficients, scatterplots, observed-pair sensitivity and within-country comparisons. The same assistant prepared both stages, which is explicitly disclosed. This is not presented as an independent student evaluation or an external conversation transcript.

If the module expects your own direct interaction with an AI tool, reuse the displayed prompt with the actual notebook results, keep that tool's actual response, and write your own evidence-based critique. Do not attribute a revised or different output to a tool that did not produce it.
