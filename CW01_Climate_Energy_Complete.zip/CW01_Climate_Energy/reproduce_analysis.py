#!/usr/bin/env python3
"""Reproduce the CW01 EDA. Run from this folder."""

# Notebook code cell 1
from pathlib import Path
from io import BytesIO
import hashlib
import json
import platform
import sys
import numpy as np
import pandas as pd
import matplotlib
import matplotlib.pyplot as plt
import seaborn as sns
from PIL import Image
try:
    from IPython.display import display
except ImportError:
    def display(obj):
        print(obj.to_string() if hasattr(obj, 'to_string') else str(obj))

pd.set_option('display.max_columns', 20)
pd.set_option('display.max_rows', 30)
pd.set_option('display.width', 140)
sns.set_theme(style='whitegrid', context='notebook', palette='colorblind')
plt.rcParams.update({'figure.dpi':110, 'savefig.dpi':160, 'axes.spines.top':False,
                     'axes.spines.right':False, 'axes.titlesize':12, 'font.size':10})
TABLES = Path('outputs/tables')
FIGURES = Path('outputs/figures')
TABLES.mkdir(parents=True, exist_ok=True)
FIGURES.mkdir(parents=True, exist_ok=True)

NUMERIC = ['avg_temperature', 'humidity', 'co2_emission', 'energy_consumption',
           'renewable_share', 'urban_population', 'industrial_activity_index', 'energy_price']
LABELS = {
    'avg_temperature':'Average temperature (°C)', 'humidity':'Relative humidity (%)',
    'co2_emission':'CO₂ emissions (dataset units)',
    'energy_consumption':'Energy consumption (dataset units)',
    'renewable_share':'Renewable energy share (%)',
    'urban_population':'Urban population (%)',
    'industrial_activity_index':'Industrial activity index',
    'energy_price':'Energy price (dataset units)'}

def table(df, name, index=True):
    df.to_csv(TABLES / (name + '.csv'), index=index)
    display(df.round(4) if isinstance(df, pd.DataFrame) else df)

def figure(name):
    fig = plt.gcf()
    fig.tight_layout()
    buffer = BytesIO()
    fig.savefig(buffer,format='png',dpi=160,bbox_inches='tight')
    image_bytes = buffer.getvalue()
    with Image.open(BytesIO(image_bytes)) as check:
        check.load()
    destination = FIGURES / (name + '.png')
    temporary = destination.with_suffix('.png.tmp')
    temporary.write_bytes(image_bytes)
    temporary.replace(destination)
    assert destination.read_bytes() == image_bytes
    with Image.open(destination) as check:
        check.load()
    display(fig)
    plt.close(fig)

print('Python', platform.python_version())
print('pandas', pd.__version__, '| NumPy', np.__version__, '| matplotlib', matplotlib.__version__, '| seaborn', sns.__version__)


# Notebook code cell 3
EXPECTED_SHA256 = '5b806df0f3ffaf45b15f617fc666e497fc36292b9fa2498ce925680e656b0d84'
EXPECTED_DATA_SHA256 = '7ae5166506753c6d9715d3d43e2cc6f98a43396db597f9a79d6036fe13ec5ac1'

def data_signature(frame):
    canonical = frame.to_csv(index=False,lineterminator='\n',float_format='%.17g')
    return hashlib.sha256(canonical.encode('utf-8')).hexdigest()

candidates = [Path('data/global_climate_energy_assessment_2026.csv'),
              Path('global_climate_energy_assessment_2026.csv'),
              Path('global_climate_energy_assessment_2026(1).csv')]
source_path = next((p for p in candidates if p.is_file()), None)
if source_path is None:
    try:
        from google.colab import files
    except ImportError as exc:
        raise FileNotFoundError('Place the supplied CSV beside this notebook or in data/.') from exc
    uploaded = files.upload()
    matching = []
    for name in uploaded:
        try:
            if data_signature(pd.read_csv(name)) == EXPECTED_DATA_SHA256:
                matching.append(Path(name))
        except (ValueError,UnicodeError,pd.errors.ParserError):
            continue
    if len(matching) != 1:
        raise ValueError('Upload exactly one copy containing the supplied assessment data.')
    source_path = matching[0]

source_hash = hashlib.sha256(source_path.read_bytes()).hexdigest()
raw = pd.read_csv(source_path)
assert raw.columns.tolist() == ['Unnamed: 0', 'date', 'country', 'region', 'income_group'] + NUMERIC
source_data_hash = data_signature(raw)
if source_data_hash != EXPECTED_DATA_SHA256:
    raise ValueError('Parsed values differ from the supplied assessment dataset. Use the provided CSV.')
if source_hash != EXPECTED_SHA256:
    print('Warning: file bytes differ, but parsed assessment data are identical. Continuing.')
print('Source:', source_path.name)
print('SHA256:', source_hash)
print('Raw dimensions:', raw.shape)
display(raw.head())
raw.info()


# Notebook code cell 4
schema = pd.DataFrame({'dtype':raw.dtypes.astype(str),
                       'missing':raw.isna().sum(),
                       'missing_pct':raw.isna().mean()*100,
                       'unique_non_null':raw.nunique()})
table(schema, '01_raw_schema')
table(raw[NUMERIC].describe().T, '02_raw_numeric_summary')
print('Exact duplicated rows:', int(raw.duplicated().sum()))
print('Duplicates ignoring export index:', int(raw.drop(columns='Unnamed: 0').duplicated().sum()))

label_issues = []
for col in ['country','region','income_group']:
    for value, n in raw[col].value_counts(dropna=False).items():
        canonical = value.strip().title() if col == 'region' else value.strip()
        if value != canonical:
            label_issues.append({'column':col,'original_repr':repr(value),
                                 'canonical':canonical,'affected_rows':n})
table(pd.DataFrame(label_issues), '03_label_issues', index=False)
parsed_dates = pd.to_datetime(raw['date'], format='%d/%m/%Y', errors='coerce')
print('Unparseable dates with explicit day/month/year:', int(parsed_dates.isna().sum()))
print('Date range:', parsed_dates.min().date(), 'to', parsed_dates.max().date())


# Notebook code cell 6
def three_sigma(df):
    rows = []
    flags = pd.DataFrame(False, index=df.index, columns=NUMERIC)
    for col in NUMERIC:
        s = df[col]
        mean, sd = s.mean(), s.std(ddof=1)
        flags[col] = ((s - mean).abs() > 3 * sd) & s.notna()
        rows.append({'variable':col, 'observed_n':int(s.notna().sum()),
                     'mean':mean, 'sample_sd':sd, 'lower_3sd':mean-3*sd,
                     'upper_3sd':mean+3*sd, 'flagged_n':int(flags[col].sum())})
    return pd.DataFrame(rows).set_index('variable'), flags

# Source row positions and the supplied export index are audit identifiers only.
duplicate_rows = raw.loc[raw.duplicated()].copy()
duplicate_rows.insert(0, 'csv_data_row', duplicate_rows.index + 1)
table(duplicate_rows, '04_removed_duplicates', index=False)
base = raw.drop_duplicates().copy()
base['source_index'] = base.pop('Unnamed: 0')
base['date'] = pd.to_datetime(base['date'], format='%d/%m/%Y', errors='raise')
for col in ['country','region','income_group']:
    base[col] = base[col].str.strip()
base['region'] = base['region'].str.title()
assert not base.duplicated(['country','date']).any(), 'Inspect conflicting country/date records.'

initial_sigma, initial_flags = three_sigma(base)
table(initial_sigma, '05_three_sigma_before_repairs')

invalid_masks = {
    'humidity':base['humidity'].notna() & ~base['humidity'].between(0,100),
    'renewable_share':base['renewable_share'].notna() & ~base['renewable_share'].between(0,100),
    'urban_population':base['urban_population'].notna() & ~base['urban_population'].between(0,100),
    'avg_temperature':base['avg_temperature'] > 60,
    'energy_price':base['energy_price'] < 0}
reasons = {
    'humidity':'Percentage outside 0 to 100',
    'renewable_share':'Percentage outside 0 to 100',
    'urban_population':'Percentage outside 0 to 100',
    'avg_temperature':'Implausible ambient average above 60 C screening bound',
    'energy_price':'Unverified negative price; retained in sensitivity alternative'}
observed = base.copy()
invalid_details = []
for col, mask in invalid_masks.items():
    for i in base.index[mask]:
        invalid_details.append({'source_index':int(base.at[i,'source_index']),
                                'country':base.at[i,'country'], 'date':base.at[i,'date'],
                                'variable':col, 'original_value':base.at[i,col],
                                'reason':reasons[col],
                                'flagged_by_raw_3sd':bool(initial_flags.at[i,col])})
    observed.loc[mask, col] = np.nan
table(pd.DataFrame(invalid_details), '06_suspect_value_decisions', index=False)

# Repeated observed endpoints can indicate clipping, but do not prove it.
endpoint_rows = []
for col in NUMERIC:
    s = observed[col].dropna()
    for endpoint,value in [('minimum',s.min()),('maximum',s.max())]:
        matches = observed[col].eq(value)
        endpoint_rows.append({'variable':col,'observed_endpoint':endpoint,'value':value,
                              'count':int(matches.sum()),'pct_of_valid':matches.sum()/len(s)*100,
                              'countries_at_endpoint':int(observed.loc[matches,'country'].nunique())})
endpoint_summary = pd.DataFrame(endpoint_rows)
table(endpoint_summary,'06b_repeated_observed_endpoints',index=False)


# Notebook code cell 9
missing_summary = pd.DataFrame({
    'original_missing':base[NUMERIC].isna().sum(),
    'newly_flagged':observed[NUMERIC].isna().sum()-base[NUMERIC].isna().sum(),
    'total_to_impute':observed[NUMERIC].isna().sum()})
missing_summary['pct_of_4000'] = missing_summary['total_to_impute'] / len(base)*100
table(missing_summary, '07_missingness_summary')
for frame, prefix in [(base,'original'), (observed,'after_quality_checks')]:
    by_country = frame.groupby('country')[NUMERIC].agg(lambda s:s.isna().sum())
    by_year = frame.groupby(frame.date.dt.year.rename('year'))[NUMERIC].agg(lambda s:s.isna().sum())
    table(by_country, '08_' + prefix + '_missing_by_country')
    table(by_year, '09_' + prefix + '_missing_by_year')

country_rates = base.groupby('country')[['renewable_share','energy_price']].agg(lambda s:s.isna().mean()*100)
fig, ax = plt.subplots(figsize=(7,5))
sns.heatmap(country_rates, annot=True, fmt='.2f', cmap='Blues', linewidths=.5,
            cbar_kws={'label':'Originally missing (%)'}, ax=ax)
ax.set_title('Original missing values by country')
ax.set_xlabel(''); ax.set_ylabel('')
figure('01_missingness_by_country')
print('Rows with any original missing value:', int(base[NUMERIC].isna().any(axis=1).sum()))
print('Rows with both renewable share and price originally missing:',
      int(base[['renewable_share','energy_price']].isna().all(axis=1).sum()))
print('Rows with any missing value after quality checks:', int(observed[NUMERIC].isna().any(axis=1).sum()))

def impute_country_median(frame):
    result = frame.copy()
    changes = []
    for col in NUMERIC:
        missing = result[col].isna()
        country_medians = frame.groupby('country')[col].transform('median')
        global_median = frame[col].median()
        assert pd.notna(global_median), f'No observed values in {col}'
        fill_values = country_medians.fillna(global_median)
        for i in result.index[missing]:
            original = base.at[i,col]
            changes.append({'source_index':int(result.at[i,'source_index']),
                            'country':result.at[i,'country'], 'date':result.at[i,'date'],
                            'variable':col, 'original_value':original,
                            'reason':'Original missing value' if pd.isna(original) else reasons[col],
                            'replacement':float(fill_values.at[i]),
                            'method':'country median' if pd.notna(country_medians.at[i]) else 'global median fallback'})
        result.loc[missing,col] = fill_values.loc[missing]
    return result, pd.DataFrame(changes)

filled, imputation_audit = impute_country_median(observed)
table(imputation_audit.head(12), '10_imputation_audit_excerpt', index=False)
imputation_audit.to_csv(TABLES/'10_imputation_audit_full.csv', index=False)
print('Total imputed cells:', len(imputation_audit))
print('Global fallback cells:', int(imputation_audit['method'].ne('country median').sum()))


# Notebook code cell 10
sigma_summary, sigma_flags = three_sigma(observed)
table(sigma_summary, '11_three_sigma_valid_observations')
outlier_records = []
for col in NUMERIC:
    for i in observed.index[sigma_flags[col]]:
        outlier_records.append({'source_index':int(observed.at[i,'source_index']),
                                'country':observed.at[i,'country'], 'date':observed.at[i,'date'],
                                'variable':col, 'value':observed.at[i,col],
                                'z_score':(observed.at[i,col]-observed[col].mean())/observed[col].std(ddof=1),
                                'decision':'Retain; no independent evidence of data-entry error'})
outlier_detail = pd.DataFrame(outlier_records)
outlier_detail.to_csv(TABLES/'12_retained_outlier_details.csv',index=False)
display(outlier_detail.head(12).round(3))
print('Flagged cells retained:', int(sigma_flags.sum().sum()))
print('Distinct rows containing retained flags:', int(sigma_flags.any(axis=1).sum()))

comparison = pd.DataFrame({
    'observed_mean':observed[NUMERIC].mean(), 'imputed_mean':filled[NUMERIC].mean(),
    'observed_sd':observed[NUMERIC].std(), 'imputed_sd':filled[NUMERIC].std()})
table(comparison, '13_imputation_effect')

clean = filled.drop(columns='source_index').sort_values(['country','date']).reset_index(drop=True)
assert clean.shape == (4000,12)
assert clean.notna().all().all()
assert np.isfinite(clean[NUMERIC].to_numpy()).all()
assert not clean.duplicated(['country','date']).any()
for col in ['humidity','renewable_share','urban_population']:
    assert clean[col].between(0,100).all()
assert clean['country'].nunique() == 10 and clean['region'].nunique() == 5
assert clean.groupby('country').size().eq(400).all()
assert clean.date.min() == pd.Timestamp('2020-01-01')
assert clean.date.max() == pd.Timestamp('2024-12-31')
table(pd.DataFrame([
    {'stage':'Raw','rows':len(raw),'columns':raw.shape[1],'missing_numeric_cells':int(raw[NUMERIC].isna().sum().sum())},
    {'stage':'Deduplicated and labels normalised','rows':len(base),'columns':12,'missing_numeric_cells':int(base[NUMERIC].isna().sum().sum())},
    {'stage':'Suspect cells set aside','rows':len(observed),'columns':12,'missing_numeric_cells':int(observed[NUMERIC].isna().sum().sum())},
    {'stage':'Country median imputed','rows':len(clean),'columns':clean.shape[1],'missing_numeric_cells':int(clean[NUMERIC].isna().sum().sum())}
]), '14_cleaning_effect', index=False)
print('Final base dataset:', clean.shape, '| date dtype:', clean.date.dtype)
date_coverage = clean.groupby('date').agg(observations=('country','size'),distinct_countries=('country','nunique'))
table(date_coverage.head(5),'31_date_coverage_excerpt')
date_coverage.to_csv(TABLES/'31_date_coverage_full.csv',date_format='%Y-%m-%d')
print('Distinct dates:',len(date_coverage),'| all shared by ten countries:',bool(date_coverage.distinct_countries.eq(10).all()))


# Notebook code cell 13
numeric_summary = clean[NUMERIC].describe(percentiles=[.25,.5,.75]).T
numeric_summary['IQR'] = numeric_summary['75%']-numeric_summary['25%']
numeric_summary['skewness'] = clean[NUMERIC].skew()
table(numeric_summary, '15_clean_numeric_summary')

fig, axes = plt.subplots(4,2,figsize=(13,13))
for ax,col in zip(axes.flat,NUMERIC):
    sns.histplot(data=clean,x=col,bins=32,color='#237b94',ax=ax)
    ax.axvline(clean[col].mean(),color='#b94b27',linestyle='--',label='Mean')
    ax.axvline(clean[col].median(),color='#222222',linestyle=':',label='Median')
    ax.set_xlabel(LABELS[col]); ax.set_ylabel('Observations')
    ax.legend(fontsize=8)
fig.suptitle('Distributions after cleaning',y=1.005,fontsize=16)
figure('02_numeric_distributions')

focus = ['co2_emission','energy_consumption','renewable_share','industrial_activity_index']
fig,axes = plt.subplots(1,4,figsize=(13,4.2))
for ax,col in zip(axes,focus):
    sns.boxplot(y=clean[col],color='#9bc8d2',ax=ax,fliersize=2)
    ax.set_ylabel(LABELS[col]); ax.set_xticks([])
fig.suptitle('Spread of the four focal numerical variables',y=1.02)
figure('03_focal_boxplots')


# Notebook code cell 15
categorical_tables = {}
for col in ['country','region','income_group']:
    counts = clean[col].value_counts().rename('observations').to_frame()
    counts['pct'] = counts['observations']/len(clean)*100
    counts['distinct_countries'] = clean.groupby(col)['country'].nunique()
    categorical_tables[col] = counts
    table(counts, '16_' + col + '_frequencies')

fig,axes = plt.subplots(1,3,figsize=(15,5))
for ax,col in zip(axes,['country','region','income_group']):
    counts = categorical_tables[col]['observations'].sort_values()
    ax.barh(counts.index,counts.values,color='#237b94')
    ax.set_axisbelow(True)
    ax.grid(False, axis='y')
    for i,v in enumerate(counts.values):
        ax.text(v+15,i,str(v),va='center',fontsize=8,zorder=5,
                bbox={'facecolor':'white','edgecolor':'none','pad':1.5})
    ax.set_xlim(0,counts.max()*1.22)
    ax.set_xlabel('Observations'); ax.set_title(col.replace('_',' ').title())
figure('04_categorical_frequencies')


# Notebook code cell 17
BANDS = ['Below 25%', '25% to below 50%', '50% to 100%']
def renewable_bands(s):
    assert s.notna().all() and s.between(0,100).all()
    values = np.select([s < 25, (s >= 25) & (s < 50), (s >= 50) & (s <= 100)],
                       BANDS, default='Invalid')
    return pd.Categorical(values,categories=BANDS,ordered=True)

boundary_test = pd.Series([0,24.999,25,49.999,50,100])
assert list(renewable_bands(boundary_test)) == [BANDS[0],BANDS[0],BANDS[1],BANDS[1],BANDS[2],BANDS[2]]
clean['renewable_band'] = renewable_bands(clean['renewable_share'])
band_summary = clean['renewable_band'].value_counts(sort=False).rename('observations').to_frame()
band_summary['pct'] = band_summary['observations']/len(clean)*100
table(band_summary, '17_renewable_band_frequencies')
fig,ax = plt.subplots(figsize=(8,4))
ax.bar(band_summary.index.astype(str),band_summary.observations,color=['#c68342','#47899d','#39765d'])
for i,row in enumerate(band_summary.itertuples()):
    ax.text(i,row.observations+25,f'{row.observations:,} ({row.pct:.3f}%)',ha='center')
ax.set_ylim(0,2000); ax.set_ylabel('Observations'); ax.set_title('Renewable share grouped by contribution')
figure('05_renewable_bands')

# Assess whether median filling moves the category distribution materially.
observed_band = pd.Series(renewable_bands(observed.loc[observed.renewable_share.notna(),'renewable_share']))
band_sensitivity = pd.DataFrame({
    'observed_only_pct':observed_band.value_counts(sort=False).reindex(BANDS)/len(observed_band)*100,
    'imputed_pct':band_summary['pct']})
band_sensitivity['change_percentage_points'] = band_sensitivity.imputed_pct-band_sensitivity.observed_only_pct
table(band_sensitivity, '18_band_imputation_sensitivity')


# Notebook code cell 20
for group in ['region','income_group']:
    cross_counts = pd.crosstab(clean[group],clean['renewable_band'],dropna=False).reindex(columns=BANDS)
    cross_pct = cross_counts.div(cross_counts.sum(axis=1),axis=0)*100
    table(cross_counts, '19_' + group + '_band_counts')
    table(cross_pct, '20_' + group + '_band_row_pct')
    ax = cross_pct.plot(kind='barh',stacked=True,figsize=(9,4.5),
                        color=['#c68342','#47899d','#39765d'])
    ax.set_xlim(0,100); ax.set_xlabel('Share of observations within group (%)')
    ax.set_ylabel(''); ax.set_title('Renewable composition by ' + group.replace('_',' '))
    ax.legend(title='Renewable band',bbox_to_anchor=(1.02,1),loc='upper left',frameon=False)
    figure('06_' + group + '_renewable_composition')

table(pd.crosstab(clean.region, clean.income_group), '21_region_income_counts')
membership = clean.groupby(['country','region','income_group'],observed=True).size().rename('observations').reset_index()
table(membership, '22_country_membership', index=False)
pivot = clean.pivot_table(values='renewable_share',index='region',columns='income_group',aggfunc='median',observed=True)
table(pivot, '23_median_renewable_pivot')
print('Blank pivot cells mean no observations, not zero renewable share.')
country_summary = clean.groupby('country')[['co2_emission','energy_consumption','renewable_share','industrial_activity_index','energy_price']].agg(['mean','median'])
table(country_summary, '24_country_numeric_summary')

country_order = clean.groupby('country')['renewable_share'].median().sort_values().index.tolist()
fig,axes = plt.subplots(1,3,figsize=(15,6),sharey=True)
for ax,col in zip(axes,['co2_emission','energy_consumption','renewable_share']):
    sns.boxplot(data=clean,x=col,y='country',order=country_order,color='#9bc8d2',
                fliersize=1.5,linewidth=.8,ax=ax)
    ax.set_xlabel(LABELS[col]); ax.set_ylabel('')
    ax.set_title({'co2_emission':'CO₂ emissions','energy_consumption':'Energy consumption',
                  'renewable_share':'Renewable share'}[col])
    ax.xaxis.set_major_locator(matplotlib.ticker.MaxNLocator(nbins=5,prune='both'))
    ax.tick_params(axis='x',labelsize=9)
fig.suptitle('Within-country distributions ordered by median renewable share',y=1.01)
figure('06b_country_numeric_boxplots')


# Notebook code cell 22
pearson = clean[NUMERIC].corr(method='pearson')
spearman = clean[NUMERIC].corr(method='spearman')
table(pearson, '25_pearson_correlation_matrix')
table(spearman, '26_spearman_correlation_matrix')
short_labels = ['Temperature','Humidity','CO₂ emissions','Energy use','Renewable share','Urban share','Industry index','Energy price']
fig,ax = plt.subplots(figsize=(11,8))
sns.heatmap(pearson,annot=True,fmt='.2f',vmin=-1,vmax=1,center=0,cmap='vlag',square=True,
            xticklabels=short_labels,yticklabels=short_labels,linewidths=.5,
            cbar_kws={'label':'Pearson correlation'},ax=ax)
ax.set_title('Pooled numerical relationships after cleaning')
ax.tick_params(axis='x',rotation=35)
for tick in ax.get_xticklabels(): tick.set_horizontalalignment('right')
figure('07_correlation_matrix')


# Notebook code cell 24
PAIRS = [('energy_consumption','co2_emission'),
         ('renewable_share','co2_emission'),
         ('industrial_activity_index','co2_emission')]
selected_rows = []
within = clean[NUMERIC] - clean.groupby('country')[NUMERIC].transform('mean')
country_means = clean.groupby('country')[NUMERIC].mean()
for x,y in PAIRS:
    observed_pair = observed[[x,y]].dropna()
    selected_rows.append({'x':x,'y':y,'pooled_Pearson':clean[x].corr(clean[y]),
                          'pooled_Spearman':clean[x].corr(clean[y],method='spearman'),
                          'observed_pair_n':len(observed_pair),
                          'observed_pair_Pearson':observed_pair[x].corr(observed_pair[y]),
                          'within_country_demeaned_r':within[x].corr(within[y]),
                          'between_country_means_r':country_means[x].corr(country_means[y])})
selected = pd.DataFrame(selected_rows)
table(selected, '27_selected_correlations', index=False)

country_correlations = pd.DataFrame({x+' vs emissions':clean.groupby('country')[[x,y]].apply(
    lambda g:g[x].corr(g[y])) for x,y in PAIRS})
table(country_correlations, '28_country_specific_correlations')

fig,axes = plt.subplots(1,3,figsize=(16,4.8))
palette = dict(zip(sorted(clean.country.unique()),sns.color_palette('tab10',10)))
for ax,(x,y) in zip(axes,PAIRS):
    sns.scatterplot(data=clean,x=x,y=y,hue='country',palette=palette,s=10,alpha=.35,linewidth=0,legend=False,ax=ax)
    ax.set_xlabel(LABELS[x]); ax.set_ylabel('CO₂ emissions (dataset units)')
    ax.set_title('Pooled r = '+format(clean[x].corr(clean[y]),'.3f'))
    if x == 'industrial_activity_index':
        ax.axvline(112,color='#805031',ls='--',lw=1,zorder=1)
        ax.text(.98,.97,'112: possible ceiling',transform=ax.transAxes,
                ha='right',va='top',fontsize=8,
                bbox={'facecolor':'white','edgecolor':'none','alpha':.9,'pad':2})
handles = [matplotlib.lines.Line2D([],[],marker='o',linestyle='',color=color,label=country)
           for country,color in palette.items()]
fig.legend(handles=handles,loc='lower center',bbox_to_anchor=(.5,-.15),ncol=5,frameon=False)
figure('08_selected_scatterplots_by_country')

fig,axes = plt.subplots(1,3,figsize=(16,4.5))
for ax,(x,y) in zip(axes,PAIRS):
    sns.scatterplot(x=within[x],y=within[y],s=8,alpha=.25,color='#237b94',linewidth=0,ax=ax)
    ax.axhline(0,color='gray',linewidth=.7);ax.axvline(0,color='gray',linewidth=.7)
    ax.set_xlabel(LABELS[x]+' deviation')
    ax.set_ylabel('CO₂ deviation from country mean')
    ax.set_title('Within-country r = '+format(within[x].corr(within[y]),'.3f'))
figure('09_within_country_scatterplots')


# Country panels avoid overlapping ten colours in one plot. Every panel for a
# given pair uses the same x and y limits, so countries can be compared fairly.
panel_names = {
    'energy_consumption':'12_country_panels_energy_emissions',
    'renewable_share':'13_country_panels_renewables_emissions',
    'industrial_activity_index':'14_country_panels_industry_emissions'}
panel_titles = {
    'energy_consumption':'Energy use and emissions by country',
    'renewable_share':'Renewable share and emissions by country',
    'industrial_activity_index':'Industry and emissions by country'}
for x,y in PAIRS:
    fig,axes = plt.subplots(5,2,figsize=(10,12),sharex=True,sharey=True)
    for ax,country in zip(axes.flat,sorted(clean.country.unique())):
        group = clean.loc[clean.country.eq(country)]
        ax.scatter(group[x],group[y],s=9,alpha=.45,color='#237b94',linewidths=0)
        ax.set_title(country+' | r = '+format(group[x].corr(group[y]),'.3f'),fontsize=10)
        ax.set_xlabel(''); ax.set_ylabel('')
        ax.tick_params(labelsize=9)
        ax.set_axisbelow(True)
        if x == 'industrial_activity_index':
            ax.axvline(112,color='#805031',ls='--',lw=.8,zorder=1)
    fig.suptitle(panel_titles[x]+' (400 records per country)',fontsize=13,y=1.015)
    fig.supxlabel(LABELS[x],fontsize=11)
    fig.supylabel('CO₂ emissions (dataset units)',fontsize=11)
    figure(panel_names[x])


# Notebook code cell 26
global_fill = observed.copy()
global_fill[NUMERIC] = observed[NUMERIC].fillna(observed[NUMERIC].median())
# Alternative treatment of the unverified negative price only.
negative_retained = filled.copy()
negative_mask = base.energy_price < 0
negative_retained.loc[negative_mask,'energy_price'] = base.loc[negative_mask,'energy_price']
# This is a sensitivity check, not a justification for deleting valid extremes.
trimmed = observed.loc[~sigma_flags.any(axis=1)].copy()
robust_rows = []
for x,y in PAIRS + [('energy_price','co2_emission')]:
    complete = observed[[x,y]].dropna()
    trimmed_pair = trimmed[[x,y]].dropna()
    robust_rows.append({'pair':x+' vs '+y,
                       'primary_country_median_r':filled[x].corr(filled[y]),
                       'observed_pair_r':complete[x].corr(complete[y]),
                       'observed_pair_n':len(complete),
                       'global_median_r':global_fill[x].corr(global_fill[y]),
                       'valid_3sd_rows_set_aside_r':trimmed_pair[x].corr(trimmed_pair[y]),
                       'trimmed_pair_n':len(trimmed_pair),
                       'negative_price_retained_r':negative_retained[x].corr(negative_retained[y])})
robustness = pd.DataFrame(robust_rows)
table(robustness, '29_robustness_checks', index=False)
delta = negative_retained.energy_price.mean()-filled.energy_price.mean()
print('Retaining -25 changes mean price by:', round(delta,6), 'dataset units')
print('Retaining -25 changes price/emissions r by:',
      round(negative_retained.energy_price.corr(negative_retained.co2_emission)-filled.energy_price.corr(filled.co2_emission),6))


# Notebook code cell 30
cleaned_path = Path('data/global_climate_energy_cleaned.csv' if Path('data').is_dir()
                    else 'outputs/global_climate_energy_cleaned.csv')
cleaned_csv = clean.to_csv(index=False,date_format='%Y-%m-%d')
temporary = cleaned_path.with_suffix('.csv.tmp')
temporary.write_text(cleaned_csv,encoding='utf-8')
temporary.replace(cleaned_path)
assert cleaned_path.read_text(encoding='utf-8') == cleaned_csv
exported_clean = pd.read_csv(cleaned_path,parse_dates=['date'])
expected_export = clean.copy()
expected_export['renewable_band'] = expected_export['renewable_band'].astype(str)
pd.testing.assert_frame_equal(expected_export,exported_clean,check_dtype=False,rtol=1e-12,atol=1e-10)
audit_flags = observed[['source_index','country','date']].copy()
for col in NUMERIC:
    audit_flags[col+'_imputed'] = observed[col].isna()
    audit_flags[col+'_valid_3sd_flag'] = sigma_flags[col]
audit_flags.to_csv(TABLES/'30_row_quality_flags.csv',index=False,date_format='%Y-%m-%d')

validation = {
    'source_sha256':source_hash, 'source_parsed_data_sha256':source_data_hash, 'raw_shape':list(raw.shape),
    'cleaned_base_shape':[4000,12], 'cleaned_with_band_shape':list(clean.shape),
    'duplicate_rows_removed':int(raw.duplicated().sum()),
    'original_missing_cells':int(base[NUMERIC].isna().sum().sum()),
    'suspect_cells_set_aside':len(invalid_details),
    'imputed_cells':len(imputation_audit),
    'country_median_fallback_cells':int(imputation_audit.method.ne('country median').sum()),
    'cleaned_csv_readback_rows':len(exported_clean),
    'cleaned_csv_sha256':hashlib.sha256(cleaned_path.read_bytes()).hexdigest(),
    'remaining_missing_cells':int(clean.isna().sum().sum()),
    'unique_country_date':bool(~clean.duplicated(['country','date']).any()),
    'countries':int(clean.country.nunique()),
    'observations_per_country':clean.groupby('country').size().to_dict(),
    'retained_three_sigma_cells':int(sigma_flags.sum().sum()),
    'retained_three_sigma_rows':int(sigma_flags.any(axis=1).sum()),
    'renewable_band_counts':{str(k):int(v) for k,v in clean.renewable_band.value_counts(sort=False).items()},
    'versions':{'python':platform.python_version(),'pandas':pd.__version__,'numpy':np.__version__,
                'matplotlib':matplotlib.__version__,'seaborn':sns.__version__}}
Path('outputs/validation_summary.json').write_text(json.dumps(validation,indent=2))
assert validation['imputed_cells'] == 206
assert validation['remaining_missing_cells'] == 0
assert validation['cleaned_with_band_shape'] == [4000,13]
assert int(band_summary.observations.sum()) == len(clean)
assert np.allclose(pearson.to_numpy(),pearson.to_numpy().T)
assert np.allclose(np.diag(pearson),1)
print('All dataset validation checks passed.')
print(json.dumps(validation,indent=2))
